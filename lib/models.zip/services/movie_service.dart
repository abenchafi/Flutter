// lib/services/movie_service.dart

import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/movie.dart';
import '../models/actor.dart';
import '../utils/constants.dart';

class MovieService {
  Future<List<Movie>> fetchPopularMovies() async {
    final response = await http.get(
      Uri.parse("${Constants.baseUrl}/movie/popular?api_key=${Constants.apiKey}"),
    );
    return _parseMovies(response);
  }

  Future<List<Movie>> fetchTopRatedMovies() async {
    final response = await http.get(
      Uri.parse("${Constants.baseUrl}/movie/top_rated?api_key=${Constants.apiKey}"),
    );
    return _parseMovies(response);
  }

  Future<List<Movie>> fetchMoviesByGenre(String genreId) async {
    final response = await http.get(
      Uri.parse("${Constants.baseUrl}/discover/movie?api_key=${Constants.apiKey}&with_genres=$genreId"),
    );
    return _parseMovies(response);
  }

  Future<List<Actor>> fetchMovieCredits(int movieId) async {
    final response = await http.get(
      Uri.parse("${Constants.baseUrl}/movie/$movieId/credits?api_key=${Constants.apiKey}"),
    );

    if (response.statusCode == 200) {
      final data = json.decode(response.body)['cast'];
      return (data as List).map((json) => Actor.fromJson(json)).toList();
    } else {
      throw Exception("Erreur lors de la récupération des crédits.");
    }
  }

  List<Movie> _parseMovies(http.Response response) {
    if (response.statusCode == 200) {
      final List<dynamic> data = json.decode(response.body)['results'];
      return data.map((json) => Movie.fromJson(json)).toList();
    } else {
      throw Exception("Erreur lors du chargement des films");
    }
  }
}
