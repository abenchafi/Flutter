import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/movie.dart';
import '../services/movie_service.dart';

class MovieProvider extends ChangeNotifier {
  List<Movie> _movies = [];
  List<Movie> get movies => _movies;

  List<Movie> _myList = [];
  List<Movie> get myList => _myList;

  final MovieService _movieService = MovieService();

  MovieProvider() {
    fetchMovies();
    loadMyList();
  }

  // Charger les films populaires depuis MovieService
  Future<void> fetchMovies() async {
    _movies = await _movieService.fetchPopularMovies();
    // Une fois les films récupérés, nous chargeons "Ma liste" en utilisant les films récupérés
    loadMyList();
    notifyListeners();
  }

  // Ajouter un film à la liste "Ma liste"
  void addToMyList(Movie movie) {
    if (!_myList.contains(movie)) {
      _myList.add(movie);
      saveMyList();
      notifyListeners();
    }
  }

  // Supprimer un film de "Ma liste"
  void removeFromMyList(Movie movie) {
    _myList.remove(movie);
    saveMyList();
    notifyListeners();
  }

  // Vérifier si un film est dans "Ma liste"
  bool isInMyList(Movie movie) {
    return _myList.contains(movie);
  }

  // Sauvegarder "Ma liste" dans SharedPreferences
  Future<void> saveMyList() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    // Nous stockons une liste d'IDs de films dans SharedPreferences
    List<String> movieIds = _myList.map((movie) => movie.id.toString()).toList();
    prefs.setStringList('my_list', movieIds);
  }

  void clearMyList() {
  _myList.clear();
  saveMyList(); // Sauvegarder la liste vide dans SharedPreferences
  notifyListeners(); // Notifier les widgets intéressés
}

  // Charger "Ma liste" depuis SharedPreferences
  Future<void> loadMyList() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String>? movieIds = prefs.getStringList('my_list');
    if (movieIds != null) {
      // Convertir les IDs en entiers
      List<int> ids = movieIds.map((id) => int.parse(id)).toList();
      // Associer les films récupérés à partir des IDs
      _myList = _movies.where((movie) => ids.contains(movie.id)).toList();
    }
    notifyListeners();
  }
}
