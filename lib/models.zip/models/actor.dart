class Actor {
  final int id;
  final String name;
  final String profilePath; // L'image de profil de l'acteur

  Actor({
    required this.id,
    required this.name,
    required this.profilePath,
  });

  // Méthode pour créer un acteur à partir du JSON
  factory Actor.fromJson(Map<String, dynamic> json) {
    return Actor(
      id: json['id'],
      name: json['name'],
      profilePath: json['profile_path'] ?? '', // Si le profil est nul, utilise une chaîne vide
    );
  }
}
