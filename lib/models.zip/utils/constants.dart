class Constants {
  static const String apiKey = "cd80b992d8716b5cfc96efe94c94a400";
  static const String baseUrl = "https://api.themoviedb.org/3";
  static const String imageUrl = "https://image.tmdb.org/t/p/w500";
}
